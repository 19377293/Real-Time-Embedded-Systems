//19377293
//Real-Tie Embbedded Systems

//LIBRARIES--------
#include "mbed.h"
#include "VL53L0X.h"

//HARDWARE---------
I2C i2c(PB_9,PB_8);
VL53L0X sensor(&i2c);
Serial usb(USBTX, USBRX, 9600);

//VARIABLES-------
float ToF = 100;
float ToF_filtered_1 = 100;
float ToF_filtered_2 = 100;
float ToF_filtered_3 = 100;
float ToF_raw;

//MAIN------------
int main(void) {


    sensor.init();
    sensor.setModeContinuous();
    sensor.startContinuous();
    

    while(1)
    {
        //COMPARSON OF FILTER 1, 2 AND 3
        ToF_raw = sensor.getRangeMillimeters();
        ToF_filtered_1 = (0.2 * ToF_filtered_1)+ (0.8 * ToF_raw);
        ToF_filtered_2 = (0.85 * ToF_filtered_2) + (0.15 * ToF_raw);
        ToF_filtered_3 = (0.7 * ToF_filtered_3) + (0.3 * ToF_raw);
        printf("Distance Raw: %.2f mm   Filter 1: %.2f mm   Filter 2: %.2f mm    Filter 3: %.2f mm\r\n", ToF_raw, ToF_filtered_1,ToF_filtered_2,ToF_filtered_3);

        wait(0.1);
    }
}
